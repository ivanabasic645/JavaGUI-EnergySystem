package v1;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.Panel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;

import javax.swing.SwingConstants;

public class Plac extends Panel {
	
	int redovi;
	int kolone;
	Parcela[][] parcele;
	private Parcela izabrana;
	private EnergetskiSistem owner;
	
	public Plac(int redovi, int kolone) {
		this.redovi = redovi;
		this.kolone = kolone;
		
		
	}
	
	@Override
	public void paint(Graphics g) {
		nacrtajParcele();
	}
	
	private void nacrtajParcele() {
		int dim = getDim();
		int step = dim / redovi;
		Graphics g = getGraphics();
		g.setColor(Color.BLUE);

		for (int i = 0; i < dim; i += step) {
			g.drawLine(0, i, dim - 1, i);
			g.drawLine(i, 0, i, dim - 1);
		}
	}
	
	private int getDim() {
		int width = owner.centralniPanel.getWidth();
		int height = owner.centralniPanel.getHeight();
		int w = width / redovi * redovi;
		int h = height / kolone * kolone;

		return Math.max(w, h);
	}

	public void izaberiParcelu(Parcela p) {
		izabrana = p;
	}
	
	private Parcela generisiParcelu() {
		Parcela p;
		double vrv = Math.random();
		if(vrv <= .3) {
			p = new VodenaPovrs();
		} else {
			p = new TravnataPovrs();
		}
		return p;
	}

}
