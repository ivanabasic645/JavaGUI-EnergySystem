package v1;

import java.awt.Color;

public class TravnataPovrs extends Parcela{
	
	public TravnataPovrs(){
		super();
		pozadina = Color.green;
		oznaka = '"';
	}

}
