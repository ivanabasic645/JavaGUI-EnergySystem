package v1;

import java.awt.Color;

public class VodenaPovrs extends Parcela {

	public VodenaPovrs(){
		super();
		pozadina = Color.CYAN;
		oznaka = '~';
	}
}
